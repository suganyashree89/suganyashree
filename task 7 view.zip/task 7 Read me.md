README – Online Business Information SQL Script
Overview

This SQL script demonstrates the creation and manipulation of a small database for an online business scenario. It includes:

Database creation

Table creation

Data insertion

View creation, alteration, and deletion

Using Example queries
Tables
1. product_information

Stores details of products available in the online business.

pro_id – Product ID (Primary Key, auto-increment starting at 2101)

pro_name – Product name (VARCHAR(100), not null)

pro_price – Product price (DECIMAL(10,2))

MFD – Manufacturing date (DATE)


2. deliverypersons_info

Stores details of delivery staff.

DI_IDS – Delivery person ID (Primary Key)

DI_NAME – Name of delivery person (VARCHAR(200))

DI_PH – Contact number (BIGINT)

3. orderstatus

Tracks the status of orders and links products with delivery staff.

OR_ID – Order ID (Primary Key)

OR_STATUS – Status of the order (COMPLETED / PENDING)

DI_IDS – Linked to delivery person (Foreign Key → deliverypersons_info.DI_IDS)

pro_id – Linked to product (Foreign Key → product_information.pro_id)



4. Views
1. view_high_price

Purpose: Displays the product(s) with the highest price.
Logic: Selects all products where pro_price equals the maximum price in the table.

2. PRODUCT_DETAILS

Purpose: Displays specific product information based on filtering criteria.

Initial Creation: Lists products where pro_price > 2000.

After Alteration: Lists products manufactured on 2025-05-12.

5. How to Use

Run the script in SQL Server Management Studio (SSMS).

Execute USE online_business_information; to select the database.

Use SELECT queries to view data from tables or views.

Modify ALTER VIEW PRODUCT_DETAILS to change filtering criteria.

6. Conclusion

This project provides a functional database design for an online business, demonstrating:

Structured data storage for products, orders, and delivery staff.

Use of views to simplify complex queries.

Relational links between tables for accurate and consistent reporting.