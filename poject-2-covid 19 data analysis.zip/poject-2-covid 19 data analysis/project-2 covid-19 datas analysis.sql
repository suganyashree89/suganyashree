create  database covid19_data;
create table patients_information(
date_no date,
state nvarchar(100),
death int,
deathConfirmed int,
deathIncrease int,
deathProbable  int,
hospitalized int,
negative int,
positive int);



BULK INSERT dbo.patients_information
FROM 'C:\Users\user\Documents\SQL Server Management Studio\covid.csv'
WITH ( FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
);

select * from patients_information;

--Clean and transform data (formatting, nulls).
--set negative value in to 0
update patients_information
set deathincrease = 0
where deathincrease < 0;

update patients_information
set state = ltrim(state);

select *  from patients_information;
--
CREATE VIEW dbo.vw_patient_summary
WITH SCHEMABINDING
AS
SELECT 
    ISNULL(state, 'UNKNOWN') AS state,              -- Replace NULL state with 'UNKNOWN'
    SUM(ISNULL(death, 0)) AS total_death,           -- Replace NULL with 0
    SUM(ISNULL(deathConfirmed, 0)) AS total_confirmed_death,
    SUM(ISNULL(deathIncrease, 0)) AS total_death_increase,
    SUM(ISNULL(deathProbable, 0)) AS total_probable_death,
    SUM(ISNULL(hospitalized, 0)) AS total_hospitalized,
    SUM(ISNULL(negative, 0)) AS total_negative,
    SUM(ISNULL(positive, 0)) AS total_positive
FROM dbo.patients_information
GROUP BY ISNULL(state, 'UNKNOWN');

select * from dbo.vw_patient_summary;

select state, total_negative,total_positive,total_hospitalized from dbo.vw_patient_summary;
--create temp table patient_summary ,statecode as primary key constraint

CREATE TABLE #TempPatientSummary (
    state NVARCHAR(100),
    total_death INT,
    total_positive INT,
    total_hospitalized INT
);

alter table #TempPatientSummary
add state_code int primary key identity(10002,1);

INSERT INTO #TempPatientSummary (state, total_death, total_positive, total_hospitalized)
SELECT 
    ISNULL(state, 'UNKNOWN') AS state,
    SUM(ISNULL(death, 0)) AS total_death,
    SUM(ISNULL(positive, 0)) AS total_positive,
    SUM(ISNULL(hospitalized, 0)) AS total_hospitalized
FROM dbo.patients_information
GROUP BY ISNULL(state, 'UNKNOWN');

select * from  #TempPatientSummary;

--Top Countries/States by Total Cases

select state, sum(isnull(positive,0)) as tot_postive from patients_information
group by state
order by tot_postive desc;

--Top Countries/States by Total Cases
SELECT 
    state,
    SUM(ISNULL(death,0)) * 100.0 / NULLIF(SUM(ISNULL(positive,0)),0) AS mortality_rate
FROM patients_information
GROUP BY state
ORDER BY mortality_rate DESC;

-- cases recorded in year of 2020
select date_no,state, isnull(death,0) as death,isnull(hospitalized,0)as hospitalized,
isnull(negative,0)as negative,
isnull(positive,0)as positive 
from patients_information
WHERE YEAR(date_no) = 2020 ;

--Top 10 Countries and States by Deaths
SELECT TOP 10 
    state,
    SUM(ISNULL(death, 0)) AS total_deaths
FROM patients_information
GROUP BY state
ORDER BY total_deaths DESC;

--positive rate %  based on state 
SELECT 
    state,
    SUM(ISNULL(positive, 0)) AS total_positive,
    SUM(ISNULL(negative, 0)) AS total_negative,
    CAST( (SUM(ISNULL(positive, 0)) * 100.0) / 
          NULLIF(SUM(ISNULL(positive, 0)) + SUM(ISNULL(negative, 0)), 0) 
          AS DECIMAL(5,2)) AS positivity_rate
FROM patients_information
GROUP BY state
ORDER BY positivity_rate DESC;

--Rank the states by daily cases
SELECT 
    date_no,
    state,
    positive,
    RANK() OVER(PARTITION BY date_no ORDER BY positive DESC) AS rank_by_cases
FROM patients_information
ORDER BY date_no, rank_by_cases;