create database online_business_retail;
create table product_inform(
pro_id int PRIMARY KEY IDENTITY(210,1),
pro_name varchar(100)NOT NULL,
pro_price VARCHAR(100)NOT NULL,
MFD date
);
INSERT INTO  product_inform (pro_name,pro_price,MFD ) VALUES('FAN','RS.2042','2025-05-12'),
('MIXER GRIENDER','RS.2042','2025-05-13'),
('JUICER','RS.3000','2025-05-16'),
('TV','RS.25000','2025-05-12'),
('WASHING MACHINE','RS.17000','2025-05-13'),
('AC','RS.45000','2025-05-12'),
('COOLER','RS.2042','2025-05-12'),
('IRONBOX','RS.2042','2025-05-12'),
('light','RS.1042','2025-05-15'),
('kettle','RS.822','2025-05-16'),
('induction','RS.3042','2025-05-12');

select * from product_inform;

Create TABLE Customer_datass(
Customer_IDs INT PRIMARY KEY IDENTITY(100,1),
Customer_names VARCHAR(100) not null,
CUStomer_PH VARCHAR(100)null,
Customer_address VARCHAR(100)null,
pro_id INT
CONSTRAINT FK_cust FOREIGN KEY(pro_id)REFERENCES  product_inform(pro_id)
);

INSERT INTO Customer_datass(Customer_names, Customer_PH, Customer_address, pro_id)
VALUES 
  ('RAM', '908767436', 'GT Street, Chennai', 210),
  ('SAM', '909876699', 'NN Street, Madurai', 214),
  ('Svia', '789008755', 'VV Street, Madurai', 217),
  ('Suriya', '67895432', 'VV Street, Madurai', 213),
  ('Sugan', '897765459', 'VV Street, Bangalore', 210),
  ('Samu', '9008776677', 'T Nagar, Chennai', 215),
  ('Sugan', '6345789754', 'VV Street, Bangalore', 219),
  ('Jhon', '7896543367', 'VRR Street, Madurai', 220);

  select * from Customer_datass;

CREATE TABLE DELIVERYPERSONS_datas(
DI_IDS INT PRIMARY KEY,
DI_NAME VARCHAR(200),
DI_PH BIGINT);
INSERT INTO DELIVERYPERSONS_datas VALUES(101,'BALU',998765490),
(201,'RAMU',8807654477),
(301,'SHANU',876543200),
(501,'rishi',5445667777),
(601,'shiva',6654367809),
(701,'anbu',6776558889),
(801,'SHEKAR',998765490);

CREATE TABLE Order_retail(
OR_ID INT PRIMARY KEY,
OR_STATUS VARCHAR(100),
DI_IDS INT,
pro_id INT,
constraint fk_pt foreign key (pro_id)references product_inform(pro_id),
constraint fk_dl foreign key (DI_IDS)references DELIVERYPERSONS_datas(DI_IDS)
);
INSERT INTO Order_retail VALUES
  (311, 'COMPLETED', 201, 210),
  (312, 'PENDING', 301, 215),
  (313, 'COMPLETED', 201, 214),
  (315, 'COMPLETED', 101, 213),
  (316, 'COMPLETED', 201, 219),
  (317, 'COMPLETED', 201, 220),
  (318, 'PENDING', 201, 215);

create table  payment_bill(
bill_no int  primary key identity(211,1),
OR_ID int,
pro_id INT,
pro_name varchar(200),
pro_price int,
payment_date date
constraint fk_obill foreign key (OR_ID)references Order_retail(OR_ID),
constraint fk_pbill foreign key (pro_id)references product_inform(pro_id));


insert into payment_bill(OR_ID,pro_id,pro_name,pro_price,payment_date)values(313,214,'WASHING MACHINE',17000 ,'2025-03-15'),
(315,213, 'TV',25000,'2025-05-16'), 
(316,219, 'KETTLE',822,'2025-07-15'),
(318,215, 'AC',45000,'2025-08-01'),
(317,220, 'INDUCTION',3042,'2025-07-15'),
(311,210, 'FAN',2042,'2025-06-19'),
(312,216, 'COOLER',2042,'2025-05-28'),
(315,213, 'TV',25000,'2025-07-16'),
(316,219, 'KETTLE',822,'2025-07-20'),
(313,214, 'WASHING MACHINE',17000,'2025-05-13');


SELECT * FROM payment_bill;

-- display each customer�s name along with the product they purchased USING INNER JOINS
CREATE VIEW CUSTOMER_PRODUCT
AS
SELECT C.customer_IDS,C.Customer_names,P.pro_ID,P.pro_name FROM Customer_datass C
INNER JOIN product_inform P
ON C.pro_ID =P.pro_ID;

SELECT * FROM CUSTOMER_PRODUCT;

--Delivery Person with Orders
create view Delivery_orders_info
as
SELECT 
    O.OR_ID,
    O.OR_STATUS,
    D.DI_NAME AS DeliveryPerson
FROM Order_retail O
INNER JOIN DELIVERYPERSONS_datas D
    ON O.DI_IDS = D.DI_IDS; 
	select *  from Delivery_orders_info;
--pending orders
SELECT 
    O.OR_ID,
    O.OR_STATUS,
    D.DI_NAME AS DeliveryPerson
FROM Order_retail O
INNER JOIN DELIVERYPERSONS_datas D
    ON O.DI_IDS = D.DI_IDS
	where or_status='pending';
--Delivery Summary
	SELECT 
    D.DI_NAME AS DeliveryPerson,
    COUNT(O.pro_id) AS ProductsDelivered
FROM Order_retail O
INNER JOIN DELIVERYPERSONS_datas D 
    ON O.DI_IDS = D.DI_IDS
GROUP BY D.DI_NAME;



