create database warehouse_management;
create table product_information(
prt_ids int primary key identity(1001,1),
prt_name varchar(100),
prt_category varchar(100),
price decimal(10,2),
 reorder_level int);

insert into product_information (prt_name,prt_category,price,reorder_level) values('Laptop Dell XPS','Electronics',45000.25,25),
('wireless mouse','Accessories',250.75,10),
('Laptop lenova XPS','Electronics',27000.25,15),
('office chair','furniture',4000.24,30),
('table','funiture',45000.25,30),
('keybord','Accessories',1000.25,15);

select * from product_information;

create table warehouse_detail(
warehouse_id int  primary key,
warehouse_name varchar(100),
location varchar(100));


insert into  warehouse_detail values(11,'head_warehouse','chennai'),
(12,'substation_warehouse1','madurai'),
(13,'substation_warehouse2','trichy'),
(14,'substation_warehouse3','coimbator');



select * from warehouse_detail;

create table Suppliers_details(
sup_ids int,
sup_name varchar(100),
contact_person varchar(100),
contact_num varchar(100));

insert into Suppliers_details values(21, 'nn company pvt', 'nivash','907645356'),
(22, 'aa company pvt', 'nikitha','923578657'),
(23, 'sri technologies pvt', 'srisha','739765439'),
(24, 'consi pvt ltd'  , 'naveen','9065799870');
select * from Suppliers_details;

create table stocks(
stock_id int primary key identity(120,1),
prt_ids int,
warehouse_id int,
quantity int,
lastupdate date,
constraint fk_pro foreign key (prt_ids) references product_information(prt_ids),
constraint fk_warhouse foreign key (warehouse_id) references warehouse_detail(warehouse_id));

insert into stocks(prt_ids,warehouse_id,quantity,lastupdate)values(1001,13,300,'2025-06-13'),
(1002,11,100,'2025-06-12'),
(1004,12,200,'2025-06-15'),
(1001,14,300,'2025-06-11'),
(1003,12,120,'2025-06-14'),
(1002,11,100,'2025-06-12'),
(1005,12,90,'2025-06-13'),
(1006,12,200,'2025-06-12');
insert into stocks(prt_ids,warehouse_id,quantity,lastupdate)values(1001,12,7,'2025-06-13');
insert into stocks(prt_ids,warehouse_id,quantity,lastupdate)values(1004,13,7,'2025-06-13');
select * from stocks;

--Current Stock asper Product

select s. prt_ids,p.prt_name,s.stock_id,s.warehouse_id,s.quantity from stocks s
inner join product_information p
on p.prt_ids =s.prt_ids;

--total stock details as per warehouse

select w.warehouse_id,w.warehouse_name,sum(s.quantity)as total_stock from warehouse_detail w
inner join stocks s
on w.warehouse_id = s.warehouse_id
group by w.warehouse_id,w.warehouse_name
order by w.warehouse_name;

--Products Safe (stock above reorder level)

select p.prt_ids,p.prt_name,s.warehouse_id,s.quantity, 
case 
when s.quantity<10 then 'not safe' 
else 'safe propduct' end as stock_status
from product_information p
inner join stocks s
on p.prt_ids = s.prt_ids;

--TIGGER FOR LOW-STOCK NOTIFICATION
CREATE TRIGGER low_stock_warning
ON stocks
AFTER INSERT, UPDATE
AS
BEGIN
    DECLARE @alert_message VARCHAR(200);

    SELECT 
        @alert_message =
            CASE 
                WHEN i.quantity < p.reorder_level 
                    THEN 'ALERT: ' + p.prt_name + ' stock is below reorder level. Current = ' + CAST(i.quantity AS VARCHAR(10))
                ELSE p.prt_name + ' stock is sufficient. Current = ' + CAST(i.quantity AS VARCHAR(10))
            END
    FROM inserted i
    INNER JOIN product_information p ON p.prt_ids = i.prt_ids;

    PRINT @alert_message
END
GO

--test  tigger automation

update stocks
set quantity = 5
where stock_id=121;


update stocks
set quantity = 45
where stock_id=122;

--STORED PROCEDURE TRANFER TASK

CREATE PROCEDURE TransferStock
    @ProductID INT,
    @FromWarehouseID INT,
    @ToWarehouseID INT,
    @Quantity INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @AvailableStock INT;

    -- 1. Check stock availability in source warehouse
    SELECT @AvailableStock = quantity
    FROM Stocks
    WHERE prt_ids = @ProductID 
      AND warehouse_id = @FromWarehouseID;

    IF @AvailableStock IS NULL OR @AvailableStock < @Quantity
    BEGIN
        RAISERROR('Not enough stock in source warehouse.', 16, 1);
        RETURN;
    END;

    -- 2. Deduct from source warehouse
    UPDATE Stocks
    SET quantity = quantity - @Quantity
    WHERE prt_ids = @ProductID 
      AND warehouse_id = @FromWarehouseID;

  -- 3. Add to destination warehouse
    IF EXISTS (SELECT 1 FROM Stocks WHERE prt_ids = @ProductID AND warehouse_id = @ToWarehouseID)
    BEGIN
        UPDATE Stocks
        SET quantity = quantity + @Quantity
        WHERE prt_ids = @ProductID AND warehouse_id = @ToWarehouseID;
    END
    ELSE
    BEGIN
        INSERT INTO Stocks (prt_ids, warehouse_id, quantity)
        VALUES (@ProductID, @ToWarehouseID, @Quantity);
    END;
END;


EXEC TransferStock 
    @ProductID = 1001, 
    @FromWarehouseID = 14, 
    @ToWarehouseID = 11, 
    @Quantity = 50;

 --All PRODUCT STOCK CHECKING IN STOREPROCEDURE
  CREATE OR ALTER PROCEDURE check_stock_all
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        p.prt_ids AS ProductID,
        p.prt_name AS ProductName,
        w.warehouse_id AS WarehouseID,
        w.warehouse_name AS WarehouseName,
        s.quantity AS AvailableStock
    FROM product_information p
    INNER JOIN stocks s ON p.prt_ids = s.prt_ids
    INNER JOIN warehouse_detail w ON w.warehouse_id = s.warehouse_id;
END;

EXEC check_stock_all;

-- SINGLE STOCK CHECKING USING STORE PROCEDURE

CREATE PROCEDURE check_stocks
    @product_name VARCHAR(100) OUTPUT,
    @warehouse_id INT OUTPUT,
    @warehouse_name VARCHAR(100) OUTPUT,
    @prt_id INT,
    @available_stocks INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        @product_name = p.prt_name,
        @warehouse_id = w.warehouse_id,
        @warehouse_name = w.warehouse_name,
        @available_stocks = s.quantity,
		@prt_id = @prt_id
    FROM product_information p
    INNER JOIN stocks s ON p.prt_ids = s.prt_ids
    INNER JOIN warehouse_detail w ON w.warehouse_id = s.warehouse_id
    WHERE p.prt_ids = @prt_id;
END;

DECLARE 
    @pname VARCHAR(100),
    @wid INT,
    @wname VARCHAR(100),
    @avail INT;
	

exec check_stocks 
  @product_name = @pname  output, @warehouse_id= @wid OUTPUT, @warehouse_name= @wname OUTPUT,   
  @prt_id = 1003, @available_stocks= @avail OUTPUT;

 select  @pname as product_name, @wid as wr_id, @wname as wr_name,  @avail as available_stock;
  




