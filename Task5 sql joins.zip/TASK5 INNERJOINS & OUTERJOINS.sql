create database online_business_information;
create table productinformation(
pro_id int PRIMARY KEY IDENTITY(2101,1),
pro_name varchar(100)NOT NULL,
pro_price VARCHAR(100)NOT NULL,
MFD date);
INSERT INTO  productinformation (pro_name,pro_price,MFD ) VALUES('FAN','RS.2042','2025-05-12'),
('MIXER GRIENDER','RS.2042','2025-05-13'),
('JUICER','RS.3000','2025-05-16'),
('TV','RS.25000','2025-05-12'),
('WASHING MACHINE','RS.17000','2025-05-13'),
('AC','RS.45000','2025-05-12'),
('COOLER','RS.2042','2025-05-12'),
('IRONBOX','RS.2042','2025-05-12');

CREATE TABLE Customerinfo(
Customer_IDs INT PRIMARY KEY IDENTITY(100,1),
Customer_names VARCHAR(100)null,
CUStomer_PH VARCHAR(100)null,
Customer_address VARCHAR(100)null,
pro_id INT
CONSTRAINT FK_info FOREIGN KEY(pro_id)REFERENCES  productinformation(pro_id)
);

INSERT INTO  Customerinfo (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('RAM','908767436','GT STREET,CHENNAI',2104);
INSERT INTO  Customerinfo (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('SAM','909876699','NN STREET,MADURAI',2105);

INSERT INTO  Customerinfo (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('','','VV STREET,MADURAI',2103);

INSERT INTO  Customerinfo (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('suriya', '','VV STREET,MADURAI',2106);
INSERT INTO  Customerinfo (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('sugan', '','VV STREET,bangaluru',null),
('samu', '9008776677','t nagarchennai',null),
('sugan', null,'VV STREET,bangaluru',null),
('rafia', null,'bangaluru',null),
('jhon', null,'Vrr STREET,madurai',null),
('ravi', null,'bangaluru',null);
select * from Customerinfo;

--USING LEFT JOIN
SELECT C.Customer_IDs,C.Customer_names,C.CUStomer_PH ,P.pro_id,P.pro_name FROM  Customerinfo AS C
LEFT JOIN  productinformation AS P
ON C.pro_id = P.pro_id;

--USING RIGHT JOIN
SELECT C.Customer_IDs,C.Customer_names,C.CUStomer_PH ,P.pro_id,P.pro_name FROM  Customerinfo AS C
RIGHT JOIN  productinformation AS P
ON C.pro_id = P.pro_id;


--USING FULL JOIN
SELECT C.Customer_IDs,C.Customer_names,C.CUStomer_PH ,P.pro_id,P.pro_name FROM  Customerinfo AS C
FULL JOIN  productinformation AS P
ON C.pro_id = P.pro_id;

--USING INNER JOIN
SELECT C.Customer_IDs,C.Customer_names,C.CUStomer_PH ,P.pro_id,P.pro_name FROM  Customerinfo AS C
INNER JOIN  productinformation AS P
ON C.pro_id = P.pro_id;

--CROSS JOIN
SELECT* FROM  productinformation AS P
CROSS JOIN   Customerinfo AS C;


--JOINS WITHOUT FOREIGNKEY
CREATE TABLE DELIVERYPERSONSINFO(
DI_IDS INT PRIMARY KEY,
DI_NAME VARCHAR(200),
DI_PH BIGINT);
INSERT INTO DELIVERYPERSONSINFO VALUES(1,'BALU',998765490),
(2,'RAMU',8807654477),
(3,'SHANU',876543200),
(4,'SHEKAR',998765490);

CREATE TABLE ORDER_STS(
OR_ID INT PRIMARY KEY,
OR_STATUS VARCHAR(100),
DI_IDS INT
);
ALTER TABLE ORDER_STS
ADD  pro_id INT;

INSERT INTO ORDER_STS VALUES(1,'COMPLETED',4,2103),
(2,'PENDING',3,2107),
(3,'COMPLETED',2,2101),
(4,'CPMPLETED',3,2104);
INSERT INTO ORDER_STS VALUES(5,'COMPLETED',2,''),
(6,'',4,''),
(7,'',2,'');
--LEFTJOIN W/O KEY
SELECT D.DI_IDS,D.DI_NAME,O.OR_STATUS,O.OR_ID FROM DELIVERYPERSONSINFO AS D
LEFT JOIN ORDER_STS AS O
ON D.DI_IDS=O.DI_IDS;
--RIGHT JOIN
SELECT D.DI_IDS,D.DI_NAME,O.OR_STATUS,O.OR_ID FROM DELIVERYPERSONSINFO AS D
RIGHT JOIN ORDER_STS AS O
ON D.DI_IDS=O.DI_IDS;

--FULLJOIN 
SELECT * FROM DELIVERYPERSONSINFO AS D
FULL JOIN ORDER_STS AS O
ON D.DI_IDS=O.DI_IDS;

