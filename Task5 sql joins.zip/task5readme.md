📘 README - Online Business Information Database
📄 Overview
This SQL script sets up a basic database called online_business_information for managing products, customers, delivery personnel, and orders in an online business scenario. It includes schema creation, data insertion, and usage of different types of SQL joins to retrieve relational data.


1. Database Name

CREATE DATABASE online_business_information;
2. Table: productinformation
Column	 |  Type	       |        Description
--------------------------------------------------------
pro_id	 |   INT (IDENTITY)|	Primary key, auto-incremented
pro_name |  VARCHAR(100)   |   Name of the product
pro_price|   VARCHAR(100)  |   Price of the product (as string)
MFD	     |   DATE	       |  Manufacturing date

✅ Contains information about each product.

3. Table: Customerinfo
Column	         |      Type	        |   Description
---------------- |------------------------------------------
Customer_IDs	 |     INT (IDENTITY)	|Primary key
Customer_names	 |     VARCHAR(100)	    |Name of the customer (nullable)
CUStomer_PH	     |    VARCHAR(100)	        |Phone number (nullable)
Customer_address |    VARCHAR(100)	    | Address
pro_id	         |    INT	            | Foreign key referencing productinformation(pro_id)

✅ Stores customer details and their purchased product (if any).

4. Table: DELIVERYPERSONSINFO
Column	|  Type	          | Description
--------|-----------------|-----------
DI_IDS	|  INT	          |  Primary key
DI_NAME	|  VARCHAR(200)	  |Delivery person’s name
DI_PH	|  BIGINT	      | Phone number

✅ Contains information about delivery personnel.

5. Table: ORDER_STS
Column	   |  Type	    |  Description
-----------|------------|----------------------
OR_ID	   | INT	    |          Primary key
OR_STATUS  |VARCHAR(100)|	Status of the order
DI_IDS	   |INT	        |         ID of the delivery person 
pro_id	   |INT	        |  ID of the product 

✅ Tracks the status of each order and optionally links to delivery personnel and products.

📥 Sample Data
Products include items like FAN, MIXER GRINDER, JUICER, TV, etc.

Customers are inserted with varying levels of data completeness.

Delivery personnel and orders are populated to test joins and optional relationships.

🔄 SQL Joins Usage
✅ With Foreign Key
LEFT JOIN:
SELECT C.Customer_IDs, C.Customer_names, C.CUStomer_PH, P.pro_id, P.pro_name 
FROM Customerinfo AS C
LEFT JOIN productinformation AS P ON C.pro_id = P.pro_id;

RIGHT JOIN:
SELECT C.Customer_IDs, C.Customer_names, C.CUStomer_PH, P.pro_id, P.pro_name 
FROM Customerinfo AS C
RIGHT JOIN productinformation AS P ON C.pro_id = P.pro_id;

FULL JOIN:
SELECT C.Customer_IDs, C.Customer_names, C.CUStomer_PH, P.pro_id, P.pro_name 
FROM Customerinfo AS C
FULL JOIN productinformation AS P ON C.pro_id = P.pro_id;

INNER JOIN:
SELECT C.Customer_IDs, C.Customer_names, C.CUStomer_PH, P.pro_id, P.pro_name 
FROM Customerinfo AS C
INNER JOIN productinformation AS P ON C.pro_id = P.pro_id;
CROSS JOIN:

SELECT * 
FROM productinformation AS P
CROSS JOIN Customerinfo AS C;
✅ Without Foreign Key (Delivery Personnel & Orders)
LEFT JOIN:

SELECT D.DI_IDS, D.DI_NAME, O.OR_STATUS, O.OR_ID 
FROM DELIVERYPERSONSINFO AS D
LEFT JOIN ORDER_STS AS O ON D.DI_IDS = O.DI_IDS;

RIGHT JOIN:
SELECT D.DI_IDS, D.DI_NAME, O.OR_STATUS, O.OR_ID 
FROM DELIVERYPERSONSINFO AS D
RIGHT JOIN ORDER_STS AS O ON D.DI_IDS = O.DI_IDS;

FULL JOIN:
SELECT * 
FROM DELIVERYPERSONSINFO AS D
FULL JOIN ORDER_STS AS O ON D.DI_IDS = O.DI_IDS;