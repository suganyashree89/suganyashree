
create database online_business_information;
create table product_information(
pro_id int PRIMARY KEY IDENTITY(2101,1),
pro_name varchar(100)NOT NULL,
pro_price VARCHAR(100)NOT NULL,
MFD date
);
INSERT INTO  product_information (pro_name,pro_price,MFD ) VALUES('FAN','RS.2042','2025-05-12'),
('MIXER GRIENDER','RS.2042','2025-05-13'),
('JUICER','RS.3000','2025-05-16'),
('TV','RS.25000','2025-05-12'),
('WASHING MACHINE','RS.17000','2025-05-13'),
('AC','RS.45000','2025-05-12'),
('COOLER','RS.2042','2025-05-12'),
('IRONBOX','RS.2042','2025-05-12');

CREATE TABLE Customer_info(
Customer_IDs INT PRIMARY KEY IDENTITY(100,1),
Customer_names VARCHAR(100)null,
CUStomer_PH VARCHAR(100)null,
Customer_address VARCHAR(100)null,
pro_id INT
CONSTRAINT FK_details FOREIGN KEY(pro_id)REFERENCES  product_information(pro_id)
);

INSERT INTO  Customer_info (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('RAM','908767436','GT STREET,CHENNAI',2104),
('SAM','909876699','NN STREET,MADURAI',2105),
('','','VV STREET,MADURAI',2103),
('suriya', '','VV STREET,MADURAI',2106),
('sugan', '','VV STREET,bangaluru',null),
('samu', '9008776677','t nagarchennai',null),
('sugan', null,'VV STREET,bangaluru',null),
('rafia', null,'bangaluru',null),
('jhon', null,'Vrr STREET,madurai',null),
('ravi', null,'bangaluru',null);

CREATE TABLE DELIVERYPERSONS_INFO(
DI_IDS INT PRIMARY KEY,
DI_NAME VARCHAR(200),
DI_PH BIGINT);
INSERT INTO DELIVERYPERSONS_INFO VALUES(101,'BALU',998765490),
(201,'RAMU',8807654477),
(301,'SHANU',876543200),
(501,'rishi',5445667777),
(601,'shiva',6654367809),
(701,'anbu',6776558889),
(801,'SHEKAR',998765490);

CREATE TABLE ORDERstatus(
OR_ID INT PRIMARY KEY,
OR_STATUS VARCHAR(100),
DI_IDS INT,
pro_id INT
);
INSERT INTO ORDERstatus VALUES(100,'COMPLETED',501,2103),
(200,'PENDING',301,2107),
(300,'COMPLETED',201,2101),
(400,'CPMPLETED',101,2104),
(500,'COMPLETED',201,2102),
(600,'completed',401,2104),
(700,'pending',201,2107);


SELECT * FROM ORDERstatus;

--USING SCALAR SUBQUERIES

--Find the name of the product with the highest price
select pro_name,pro_price from product_information 
where pro_price = (select max(pro_price)from product_information as highest_pro_price);

--Name of the product ordered by the customer with the name 'suriya'

select pro_id,pro_name,pro_price from product_information
where pro_id = (select pro_id from Customer_info where Customer_names ='suriya');

-- Name of the delivery person who completed the most orders

SELECT DI_NAME FROM DELIVERYPERSONS_INFO
WHERE DI_IDS = (SELECT TOP 1 DI_IDS FROM ORDERstatus WHERE OR_STATUS = 'COMPLETED' GROUP BY DI_IDS
                ORDER BY COUNT(*) DESC);

--Find price of the product with the HIGHEST  AND LOWEST MFD date using "IN"
  SELECT MFD,pro_price FROM product_information WHERE  MFD IN (SELECT MAX(MFD) FROM product_information );

 SELECT MFD,pro_price FROM product_information WHERE  MFD IN (SELECT MIN(MFD) FROM product_information );

 --Find the total number of products bought by the customer 'RAM' using "exists" and 'in"
	select count(pro_id) from Customer_info 
	where exists(select Customer_names Customer_info where Customer_names in('ram','suriya'));

--USING CORELATED SUBQUERIES

--Find customers who purchased products priced above the average product price USING "EXISTS"

SELECT C.pro_id, 
       C.Customer_IDs, 
       C.Customer_names
FROM Customer_info C
WHERE EXISTS (
    SELECT 1
    FROM product_information P
    WHERE P.pro_id = C.pro_id
      AND CONVERT(INT, REPLACE(P.pro_price, 'RS.', '')) = (
          SELECT MAX(CONVERT(INT, REPLACE(pro_price, 'RS.', '')))
          FROM product_information
      )
      AND CONVERT(INT, REPLACE(P.pro_price, 'RS.', '')) >
          (
              SELECT AVG(CONVERT(INT, REPLACE(pro_price, 'RS.', '')))
              FROM product_information));
--Find delivery persons who completed more orders than the average completed orders of all delivery persons using corelated subquery
SELECT d.DI_IDS, d.DI_NAME
FROM DELIVERYPERSONS_INFO d
WHERE d.DI_IDS = (
    SELECT TOP 1 O.DI_IDS
    FROM ORDERstatus O
    WHERE O.DI_IDS = d.DI_IDS
      AND O.DI_IDS > 1  and OR_STATUS = 'COMPLETED'  GROUP BY DI_IDS ORDER BY COUNT(*) DESC);

	  -- avg of completed orders = 1
