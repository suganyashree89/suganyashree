# Online Business Information – SQL Practice

This project contains SQL scripts for:
- Creating a sample **online business database**.
- Populating it with sample data.
- Running **Scalar Subqueries** and **Correlated Subqueries** for learning and interview practice.
📂 Database Structure
product_information – Stores product details (ID, Name, Price, MFD date)

Customer_info – Stores customer details linked to purchased products

DELIVERYPERSONS_INFO – Stores delivery personnel details

ORDERstatus – Stores order status linked to delivery and product

🛠 Key Features
Scalar Subqueries – Find highest-priced product, . Product ordered by customer 'suriya', most active delivery person

IN Clause – Get products with highest and lowest manufacturing dates

EXISTS Clause – Count customer purchases based on conditions

Correlated Subqueries – Compare product prices to averages, find top delivery performers

It demonstrates Scalar and Correlated Subqueries including:

Highest/lowest priced products and MFD dates.

Customers who bought above-average priced products.

Delivery person with the most completed orders.

Using IN, EXISTS, and aggregation inside subqueries.