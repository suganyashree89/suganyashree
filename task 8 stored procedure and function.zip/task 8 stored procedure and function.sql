create database online_business_informations;
create table product_informations(
pro_id int PRIMARY KEY IDENTITY(2101,1),
pro_name varchar(100)NOT NULL,
pro_price VARCHAR(100)NOT NULL,
MFD date
);
INSERT INTO  product_informations (pro_name,pro_price,MFD ) VALUES('FAN','RS.2042','2025-05-12'),
('MIXER GRIENDER','RS.2042','2025-05-13'),
('JUICER','RS.3000','2025-05-16'),
('TV','RS.25000','2025-05-12'),
('WASHING MACHINE','RS.17000','2025-05-13'),
('AC','RS.45000','2025-05-12'),
('COOLER','RS.2042','2025-05-12'),
('IRONBOX','RS.2042','2025-05-12');

SELECT * FROM product_informations;
CREATE TABLE Customer_infomation(
Customer_IDs INT PRIMARY KEY IDENTITY(100,1),
Customer_names VARCHAR(100)null,
CUStomer_PH VARCHAR(100)null,
Customer_address VARCHAR(100)null,
pro_id INT
CONSTRAINT FK_infomation FOREIGN KEY(pro_id)REFERENCES  product_information(pro_id)
);

INSERT INTO  Customer_infomation (Customer_names ,CUStomer_PH ,Customer_address,pro_id)VALUES('RAM','908767436','GT STREET,CHENNAI',2104),
('SAM','909876699','NN STREET,MADURAI',2105),
('','','VV STREET,MADURAI',2103),
('suriya', '','VV STREET,MADURAI',2106),
('sugan', '','VV STREET,bangaluru',2103),
('samu', '9008776677','t nagarchennai',2108),
('sugan', null,'VV STREET,bangaluru',2101),
('rafia', null,'bangaluru',2106),
('jhon', null,'Vrr STREET,madurai',2103),
('ravi', null,'bangaluru',2104);

CREATE TABLE DELIVERYPERSONS_Information(
DI_IDS INT PRIMARY KEY,
DI_NAME VARCHAR(200),
DI_PH BIGINT);
INSERT INTO DELIVERYPERSONS_information VALUES(101,'BALU',998765490),
(201,'RAMU',8807654477),
(301,'SHANU',876543200),
(501,'rishi',5445667777),
(601,'shiva',6654367809),
(701,'anbu',6776558889),
(801,'SHEKAR',998765490);

CREATE TABLE ORD_STATUS(
OR_ID INT PRIMARY KEY,
OR_STATUS VARCHAR(100),
DI_IDS INT,
pro_id INT
);
INSERT INTO ORD_STATUS VALUES(100,'COMPLETED',501,2103),
(200,'PENDING',301,2107),
(300,'COMPLETED',201,2101),
(400,'CPMPLETED',101,2104),
(500,'COMPLETED',201,2102),
(600,'completed',401,2104),
(700,'pending',201,2107);




SELECT * FROM ORD_STATUS;
select * from  product_informations;

--STORED PROCEDURE

CREATE PROCEDURE ST_PRODUCT_PRICE
AS
BEGIN
SET NOCOUNT ON
SELECT C.pro_id, 
       C.Customer_IDs, 
       C.Customer_names
FROM Customer_info C
WHERE EXISTS (
    SELECT 1
    FROM product_information P
    WHERE P.pro_id = C.pro_id
      AND CONVERT(INT, REPLACE(P.pro_price, 'RS.', '')) = (
          SELECT MAX(CONVERT(INT, REPLACE(pro_price, 'RS.', '')))
          FROM product_information
      )
      AND CONVERT(INT, REPLACE(P.pro_price, 'RS.', '')) >
          (
              SELECT AVG(CONVERT(INT, REPLACE(pro_price, 'RS.', '')))
              FROM product_information));

	END
	EXEC ST_PRODUCT_PRICE;

	--USING STORED procedure IN parameter
create procedure stored_ORD_STATUS 
 @OR_STATUS VARCHAR(50) --input parameter

as
begin
 set nocount on;
select OR_ID,DI_IDS,pro_id,OR_STATUS from ORD_STATUS

where OR_STATUS = @OR_STATUS;
end;
go

EXEC stored_ORD_STATUS @OR_STATUS = 'completed';

--USING STORED  procedure IN /out parameter

CREATE PROCEDURE count_ORD_STATUS
    @OR_STATUS VARCHAR(50),     -- Input parameter
    @Order_Count INT OUTPUT     -- Output parameter
AS
BEGIN
    SET NOCOUNT ON;

    -- Get count of matching rows
    SELECT @Order_Count = COUNT(*)
    FROM ORD_STATUS
    WHERE OR_STATUS = @OR_STATUS;

   
    SELECT OR_ID, DI_IDS, pro_id, OR_STATUS
    FROM ORD_STATUS
    WHERE OR_STATUS = @OR_STATUS;
END;
GO
DECLARE @Count INT;
EXEC count_ORD_STATUS 
     @OR_STATUS = 'completed', 
     @Order_Count = @Count OUTPUT;
--Function with condition

CREATE FUNCTION fn_GetOrders_ByStatus
(
    @Status VARCHAR(50)  -- Input parameter
)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        O.OR_ID,
        O.OR_STATUS,
        C.Customer_names,
        P.pro_name,
        P.pro_price,
        D.DI_NAME
    FROM ORD_STATUS AS O
    INNER JOIN product_informations AS P
        ON O.pro_id = P.pro_id
    INNER JOIN Customer_infomation AS C
        ON P.pro_id = C.pro_id
    LEFT JOIN DELIVERYPERSONS_Information AS D
        ON O.DI_IDS = D.DI_IDS
    WHERE O.OR_STATUS = @Status  -- Condition
);
GO
SELECT * FROM dbo.fn_GetOrders_ByStatus('COMPLETED');
SELECT * FROM dbo.fn_GetOrders_ByStatus('PENDING');

--Get Delivery Person Workload USING FUNCTION
CREATE FUNCTION fn_GetDeliveryWorkload()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        D.DI_NAME,
        COUNT(O.OR_ID) AS TotalOrders
    FROM DELIVERYPERSONS_Information AS D
    LEFT JOIN ORD_STATUS AS O
        ON D.DI_IDS = O.DI_IDS
    GROUP BY D.DI_NAME
);
GO

SELECT * FROM dbo.fn_GetDeliveryWorkload();